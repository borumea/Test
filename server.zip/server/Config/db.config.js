// server/db.config.js
module.exports = {
  host: "localhost",
  user: "Zapier",
  password: "Dbuser_2025!Zapier$T4T",
  database: "T4T",
  port: 3001
};